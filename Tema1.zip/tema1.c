#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "compare.h"

#define MIN_VALUE -1000000000
#define MAX_SIZE 20001

typedef struct Node{
	char *word;
	int priority;
}Node,*TNode,**ANode;


typedef struct List{
	Node **array;
	int dimension;
	int current_dimension;
}List,*TList;

/*functie care returneaza parintele unui nod*/
int getParent(int n)
{
	if(n == 0)
		return MIN_VALUE;
	else
		return (n-1)/2;
}

/*functie care intoarce copilul cu prioritatea cea mai mare
 si care e mai mare ca prioritatea parintelui*/
int getBiggestSon(TList list,int index)
{


	int left_priority = MIN_VALUE;
	int right_priority = MIN_VALUE;

	int current_priority = list->array[index]->priority;
	if(2*index + 1 < list->current_dimension)
		left_priority = list->array[2*index + 1]->priority;
	if(2*index + 2 < list->current_dimension)
		right_priority = list->array[2*index + 2]->priority;

	//nodul current e mai mare decat copii 
	if(compare(current_priority,left_priority) > 0 
		&& compare(current_priority,right_priority) > 0)
		return -1;
	
	int index_son = -1;
	
	if(compare(left_priority,right_priority) < 0)
		index_son = 2*index + 2;
	else if(compare(left_priority,right_priority) > 0)
		index_son = 2*index + 1;

	return index_son;
}
/*functie care urca un nod proaspat inserat pana se reface
conditia de max-heap*/
void propagateUp(TList list,int index_node)
{
	if(index_node == 0)
		return;
	/*cat timp prioritatea nodului curent > prioritatea parintelui */
	while(getParent(index_node) >= 0 && 
	compare(list->array[getParent(index_node)]->priority,
	list->array[index_node]->priority) < 0){
		Node* aux = list->array[getParent(index_node)];
		list->array[getParent(index_node)] = list->array[index_node];
		list->array[index_node] = aux;
		index_node = getParent(index_node);
	}
}

/*functie care coboara un nod adus de la sfarsit ca urmare a operatiei de pop*/
void propagateDown(TList list,int index_node){
	/*daca avem doar un sg node in lista sau niciunul*/
	if(list->current_dimension == 0 || list->current_dimension == 1)
		return;

	int index_son = -1;

	/*cat timp exista un copil de prioritate mai mare ca al parintelui
	 interschimba nodurile*/
	while((index_son = getBiggestSon(list,index_node)) != -1){
		/*interschimba parinte cu copilul de prioritate maxima*/
		Node* aux = list->array[index_node];
		list->array[index_node] = list->array[index_son];
		list->array[index_son] = aux;
		index_node = index_son;
	}
}

/*functie care dubleaza array-ul in cazul in care s-a atins limita alocata*/
int resize(TList list)
{
	int i;
	list->dimension = list->dimension*2;
	Node **new_list = (Node**)malloc(list->dimension*sizeof(Node*));
	if(new_list == NULL)
		return 12;

	for(i = 0;i < list->current_dimension;i++){
		new_list[i] = (Node*)malloc(sizeof(Node));
		if(new_list[i] == NULL)
			return 12;
	}

	int current_dimension = list->current_dimension;
	
	for(i = 0; i < current_dimension; i++){
		if(memcpy(new_list[i],list->array[i],sizeof(Node)) == NULL)
			return 12;
	}
	
	/*dezaloca vechiul array*/
	for(i = 0;i < list->current_dimension;i++){
		if(list->array[i]){
			free(list->array[i]);
			list->array[i] = NULL;
		}

	}

	free(list->array);
	list->array = new_list;

	return 0;
}

/*insereaza un nod in array,apeland si propagateUp*/
int insertNode(TList list,Node* node)
{
	if(list->current_dimension == list->dimension){
		int exit_code = resize(list);
		if(exit_code == 12)
			return exit_code;
	}
	
	list->array[list->current_dimension++] = node;
	propagateUp(list,list->current_dimension-1);
	return 0;
}

/* returneaza nodul de la pozitia arr[0]*/
Node* top(TList list)
{
	if(list->current_dimension == 0)
		return NULL;

	return list->array[0];
}
/*extrage maximul si reface max-heapul*/
Node* pop(TList list)
{
	if(list->current_dimension == 0)
		return NULL;

	Node* res = list->array[0];
	list->array[0] = list->array[list->current_dimension-1];
	list->array[list->current_dimension - 1] = NULL;
	list->current_dimension--;

	propagateDown(list,0);

	return res;
}

/*parseaza o linie in cuvinte in functie de '\n',' '*/
int applyCommand(char *line,TList list)
{
	/*o comanda valida are cel mult 3 componente(pt insert)*/
	int max_no_words = 3;
	char **words = (char**)malloc(max_no_words*sizeof(char*));
	if(words == NULL)
		return 12;

	int i = 0;
	char c;

	for(i = 0;i < max_no_words; i++){
		words[i] = (char*)malloc(MAX_SIZE*sizeof(char));
		if(words[i] == NULL)
			return 12;
	}

	int no_words = 0;

	i = 0;
	c = line[i];
	do{
		
		/*daca avem un inceput de cuvant*/
		if(c != ' ' && c != '\n'){
			no_words++;
			/*daca avem mai mult de 3 cuvinte parsate iesim*/
			if(no_words == 4)
				break;
			
			int current_index = 0;
			while(c != ' ' && c!= '\n')
			{
				words[no_words-1][current_index++] = c;
				c = line[++i];
			}
			words[no_words-1][current_index] = '\0';

		}else
			i++;

		c = line[i];

	}while(c != '\n' && c != EOF && i < strlen(line));

	if(no_words == 1)
	{
		if(strcmp(words[0],"top") == 0)
		{
			Node* node = top(list);
			if(node != NULL)
				printf("%s\n",node->word);
		}
		if(strcmp(words[0],"pop") == 0)
		{
			Node* aux = pop(list);
			if(aux != NULL)
			{
				if(aux->word)
					free(aux->word);
				free(aux);
			}

		}

		
	}

	else if(no_words == 3)
	{
		if(strcmp(words[0],"insert") == 0)
		{
			Node *aux = (Node*)malloc(sizeof(Node));
			if(aux == NULL)
				return 12;
			aux->word = strdup(words[1]);
			if(aux->word == NULL)
				return 12;
			aux->priority = atoi(words[2]);
			int exit_code = insertNode(list,aux);
			if(exit_code == 12)
				return exit_code;
		}
	}

	/*dezaloca bufferele pentru cuvinte*/
	for(i = 0 ;i < max_no_words ;i++)
		free(words[i]);
	free(words);

	return 0;
}


int main(int argc,char** argv){
	/*aloca lista*/
	TList list = (TList)malloc(sizeof(List));
	if(list == NULL)
		return 12;

	list->dimension = 5;
	list->current_dimension = 0;
	list->array = (Node**)malloc(list->dimension*sizeof(Node*));
	if(list->array == NULL)
		return 12;

	char *buffer = (char*)malloc(MAX_SIZE*sizeof(char));
	if(buffer == NULL)
		return 12;
	/*citeste de la tastatura*/
	if(argc == 1){
		while(fgets(buffer,MAX_SIZE,stdin)){
			int exit_code = applyCommand(buffer,list);
			if(exit_code == 12)
				return exit_code;
		}
	}else{
		/*cisteste din fisiere*/
		int i;
		for(i = 1;i <= argc -1; i++){
			FILE *f = fopen(argv[i],"r");
			if(f == NULL)
				continue;
			while(fgets(buffer,MAX_SIZE,f)){
				int exit_code = applyCommand(buffer,list);
				if(exit_code == 12)
					return exit_code;
			}

			fclose(f);

		}


	}

	/*dezaloca bufere + lista*/

	free(buffer);

	int i = 0;
	for(i = 0;i < list->current_dimension;i++){
		if(list->array[i]){
			if(list->array[i]->word != NULL){
				free(list->array[i]->word);
			}
			free(list->array[i]);
		}
	}
	free(list->array);
	free(list);
	return 0;
}
